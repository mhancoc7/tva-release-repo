hasran = 'false'
