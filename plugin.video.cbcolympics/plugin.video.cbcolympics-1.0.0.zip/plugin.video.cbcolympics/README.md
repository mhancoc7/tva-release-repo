CBC Olympics
============

A Kodi/XBMC plugin for watching the CBC Olympics streams
